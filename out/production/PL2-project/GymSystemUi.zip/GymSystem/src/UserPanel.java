package GymSystem.src;
import javax.swing.*;
import java.awt.*;
class UserPanel extends JFrame {
    public UserPanel() {
        setTitle("User - " + " ");
        setSize(400,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        add(new JLabel("Welcome, " + ""), BorderLayout.CENTER);
        JPanel top = new JPanel(new BorderLayout());
        top.add(new JLabel("Logged in as: " + " "), BorderLayout.WEST);
        JButton btnLogout = new JButton("Logout"); btnLogout.addActionListener(e->logout());
        top.add(btnLogout, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        JButton btnEdit = new JButton("Update info");
        btnEdit.addActionListener(e->updateInfo());
        add(btnEdit, BorderLayout.SOUTH);
    }
    void updateInfo() {
    }
    void logout() {
        this.dispose();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}