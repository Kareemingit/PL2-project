package GymSystem.src;
import javax.swing.*;
import java.awt.*;

class LoginFrame extends JFrame {
        JTextField txtUser;
        JPasswordField txtPass;
        public LoginFrame() {
            setTitle("Gym Management System - Login");
            setSize(360,220);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());

            JPanel p = new JPanel(new GridLayout(3,2,6,6));
            p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
            p.add(new JLabel("Username:"));
            txtUser = new JTextField();
            p.add(txtUser);
            p.add(new JLabel("Password:"));
            txtPass = new JPasswordField();
            p.add(txtPass);

            JButton btnLogin = new JButton("Login");
            btnLogin.addActionListener(e -> doLogin());
            JButton btnExit = new JButton("Exit");
            btnExit.addActionListener(e -> System.exit(0));
            JPanel btnP = new JPanel();
            btnP.add(btnLogin);
            btnP.add(btnExit);

            add(p, BorderLayout.CENTER);
            add(btnP, BorderLayout.SOUTH);

            // enter to login
            txtPass.addActionListener(e->doLogin());
            txtUser.addActionListener(e->txtPass.requestFocusInWindow());
        }

        void doLogin() {
            AdminPanel p = new AdminPanel();
            //CoachPanel p = new CoachPanel();
            //MemberPanel p = new MemberPanel();
            //UserPanel p = new UserPanel();
            p.setVisible(true);
        }

        void checkSubscriptionNotifications() {

        }
    }