package GymSystem.src;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

class CoachMembersPanel extends JPanel {
    CoachPanel parent;
    JTable tbl; DefaultTableModel model;
    public CoachMembersPanel(CoachPanel p) {
        this.parent = p;
        setLayout(new BorderLayout());
        model = new DefaultTableModel(new Object[]{"MemberID","Name","SubscriptionEnd"},0){ public boolean isCellEditable(int r,int c){return false;} };
        tbl = new JTable(model);
        refresh();

        JPanel top = new JPanel();
        JButton btnRefresh = new JButton("Refresh"); btnRefresh.addActionListener(e->refresh());
        JButton btnMessage = new JButton("Message selected member"); btnMessage.addActionListener(e->messageMember());
        top.add(btnRefresh); top.add(btnMessage);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(tbl), BorderLayout.CENTER);
    }

    void refresh() {
    }

    void messageMember() {
    }
}

class CoachSchedulesPanel extends JPanel {
    CoachPanel parent;
    JTable tbl; DefaultTableModel model;
    public CoachSchedulesPanel(CoachPanel p) {
        this.parent = p;
        setLayout(new BorderLayout());
        model = new DefaultTableModel(new Object[]{"ID","Member","Description","Start","End"},0){ public boolean isCellEditable(int r,int c){return false;} };
        tbl = new JTable(model);
        refresh();

        JPanel top = new JPanel();
        JButton btnAdd = new JButton("Add Schedule"); btnAdd.addActionListener(e->addSchedule());
        JButton btnDelete = new JButton("Delete"); btnDelete.addActionListener(e->deleteSchedule());
        JButton btnRefresh = new JButton("Refresh"); btnRefresh.addActionListener(e->refresh());
        top.add(btnAdd); top.add(btnDelete); top.add(btnRefresh);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(tbl), BorderLayout.CENTER);
    }
    void refresh() {
    }
    void addSchedule() {

    }
    void deleteSchedule() {
    }
}

class CoachMessagesPanel extends JPanel {
    CoachPanel parent;
    JTable tbl; 
    DefaultTableModel model;
    public CoachMessagesPanel(CoachPanel p) {
            this.parent = p;
            setLayout(new BorderLayout());
            model = new DefaultTableModel(new Object[]{"ID","To User","Content","Date"},0){ public boolean isCellEditable(int r,int c){return false;} };
            tbl = new JTable(model);
            refresh();

            JPanel top = new JPanel();
            JButton btnRefresh = new JButton("Refresh"); btnRefresh.addActionListener(e->refresh());
            top.add(btnRefresh);

            add(top, BorderLayout.NORTH);
            add(new JScrollPane(tbl), BorderLayout.CENTER);
    }
    void refresh() {
    }
}

public class CoachPanel extends JFrame {
        public CoachPanel() {
            setTitle("Coach Dashboard - " + " ");
            setSize(800,600);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JTabbedPane tabs = new JTabbedPane();
            tabs.add("My Members", new CoachMembersPanel(this));
            tabs.add("Schedules", new CoachSchedulesPanel(this));
            tabs.add("Messages", new CoachMessagesPanel(this));
            add(tabs, BorderLayout.CENTER);

            JPanel top = new JPanel(new BorderLayout());
            top.add(new JLabel("Logged in as: " + " " + " (COACH)"), BorderLayout.WEST);
            JButton btnLogout = new JButton("Logout"); btnLogout.addActionListener(e->logout());
            top.add(btnLogout, BorderLayout.EAST);
            add(top, BorderLayout.NORTH);
        }
        void logout() {
            this.dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        }
    }
