package GymSystem.src;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import java.nio.file.*;

public class GymManagementSystem {
    static final Path DATA_DIR = Paths.get("data");
    static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ISO_LOCAL_DATE; // yyyy-MM-dd

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginFrame lf = new LoginFrame();
            lf.setVisible(true);
        });
    }
}