package GymSystem.src;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

class MemberProfilePanel extends JPanel {
    MemberPanel parent;
    JLabel lblEnd, lblCoach;
    public MemberProfilePanel(MemberPanel p) {
        this.parent = p;
        setLayout(new GridLayout(6,1,6,6));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JLabel lblName = new JLabel("Name: " + " ");
        lblEnd = new JLabel("Subscription ends: ");
        lblCoach = new JLabel("Coach: ");
        JButton btnUpdate = new JButton("Update Info");
        btnUpdate.addActionListener(e->updateInfo());
        JButton btnRenew = new JButton("Renew subscription (extend by months)");
        btnRenew.addActionListener(e->renew());
        add(lblName); add(lblEnd); add(lblCoach); add(btnUpdate); add(btnRenew);
        refresh();
    }
    void refresh() {

    }
    void updateInfo() {

    }
    void renew() {
    }
}

class MemberSchedulePanel extends JPanel {
    MemberPanel parent;
    JTable tbl; DefaultTableModel model;
    public MemberSchedulePanel(MemberPanel p) {
        this.parent = p;
        setLayout(new BorderLayout());
        model = new DefaultTableModel(new Object[]{"ID","Coach","Description","Start","End"},0){ 
            public boolean isCellEditable(int r,int c){return false;} 
        };
        tbl = new JTable(model);
        refresh();
        add(new JScrollPane(tbl), BorderLayout.CENTER);
        JPanel top = new JPanel();
        JButton btnRefresh = new JButton("Refresh"); btnRefresh.addActionListener(e->refresh());
        top.add(btnRefresh);
        add(top, BorderLayout.NORTH);
    }
    void refresh() {
    }
}

class MemberMessagesPanel extends JPanel {
    MemberPanel parent;
    JTable tbl; DefaultTableModel model;
    public MemberMessagesPanel(MemberPanel p) {
        this.parent = p;
        setLayout(new BorderLayout());
        model = new DefaultTableModel(new Object[]{"ID","From","Content","Date"},0){ 
            public boolean isCellEditable(int r,int c){return false;} 
        };
        tbl = new JTable(model);
        refresh();
        add(new JScrollPane(tbl), BorderLayout.CENTER);
        JPanel top = new JPanel();
        JButton btnRefresh = new JButton("Refresh"); btnRefresh.addActionListener(e->refresh());
        top.add(btnRefresh);
        add(top, BorderLayout.NORTH);
    }
    void refresh() {
    }
}

class MemberPanel extends JFrame {
    public MemberPanel() {
        setTitle("Member Portal - " + " ");
        setSize(700,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Profile", new MemberProfilePanel(this));
        tabs.add("Schedule", new MemberSchedulePanel(this));
        tabs.add("Messages", new MemberMessagesPanel(this));
        add(tabs, BorderLayout.CENTER);

        JPanel top = new JPanel(new BorderLayout());
        top.add(new JLabel("Logged in as: " + " " + " (MEMBER)"), BorderLayout.WEST);
        JButton btnLogout = new JButton("Logout"); btnLogout.addActionListener(e->logout());
        top.add(btnLogout, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);
    }
    void logout() {
        this.dispose();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
